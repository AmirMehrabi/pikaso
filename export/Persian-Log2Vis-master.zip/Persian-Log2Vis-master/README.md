## Persian Log2Vis version 2

**Persian Log2Vis** is a library to convert all Arabic-based languages (eg. Persian/Farsi, Arabic, Dari, Pashto, Panjabi, Urdu and ...) texts to image.


